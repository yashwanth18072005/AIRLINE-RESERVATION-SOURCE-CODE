package Project;

public interface PaymentService {
    void processPayment();
}
